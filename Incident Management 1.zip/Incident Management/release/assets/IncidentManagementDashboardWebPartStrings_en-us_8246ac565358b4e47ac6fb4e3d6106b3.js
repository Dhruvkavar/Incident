define([], function() {
  return {
    "ListName": "List Title",
    "ListColumns": "List Columns",
    "viewEditURL":"View Edit URL"
  }
});