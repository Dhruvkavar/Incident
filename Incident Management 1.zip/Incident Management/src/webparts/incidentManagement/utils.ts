import { getSP } from "./getSP";
import "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/fields";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/site-users/web";

export default class Utility {
    public async saveItem(item: any, lstName: any): Promise<any> {
        try {
            const _sp = getSP();
            const data = await _sp.web.lists.getByTitle(lstName).items.add(item)
            return data;
        } catch (error) {
            console.error("An error occurred while adding new record to the list", error);
            throw error; // Optionally rethrow the error for further handling
        }
    }

    public async updateItem(Id: any, lstName: any, item: any, status: string): Promise<any> {
        try {
            const _sp = getSP();
            item.Status = status;
            const data = await _sp.web.lists.getByTitle(lstName).items.getById(Id).update(item);
            return data;
        } catch (error) {
            console.error("An error occurred while adding new record to the list", error);
            throw error; // Optionally rethrow the error for further handling
        }
    }

    public async getSelectedItem(Id: number, lstName: any): Promise<any> {
        try {
            const _sp = getSP();
            const data = await _sp.web.lists.getByTitle(lstName).items.getById(Id).select("*,ApplicationOwner/Id,ApplicationOwner/EMail").expand("ApplicationOwner")();
            return data;
        } catch (error) {
            console.error("An error occurred while adding new record to the list", error);
            throw error; // Optionally rethrow the error for further handling
        }
    }

    public async getUsers(Ids: string | string[]): Promise<any[]> {
        let userIds = Array.isArray(Ids) ? Ids : [Ids];
        let users = [];
        try {
            const _sp = getSP();
            for (const Id of userIds) {
                const data = await _sp.web.getUserById(parseInt(Id))();
                users.push(data.Email);
            }
            return users;
        } catch (error) {
            console.error("An error occurred while fetching user details", error);
            throw error;
        }
    }

}