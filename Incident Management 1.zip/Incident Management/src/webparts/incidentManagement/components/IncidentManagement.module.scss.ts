/* tslint:disable */
require("./IncidentManagement.module.css");
const styles = {
  Header: 'Header_f123e2f9',
  HeaderText: 'HeaderText_f123e2f9',
  Yesbtn: 'Yesbtn_f123e2f9',
  cancelButton: 'cancelButton_f123e2f9',
  ResolutionTimePicker: 'ResolutionTimePicker_f123e2f9'
};

export default styles;
/* tslint:enable */