export interface IIncidentManagementProps {
  lists: any;
  context: any
  webpartTitle:string
}
