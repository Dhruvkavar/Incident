declare interface IIncidentManagementDashboardWebPartStrings {
  ListName: string;
  ListColumns: string;
  viewEditURL: string;
}

declare module 'IncidentManagementDashboardWebPartStrings' {
  const strings: IIncidentManagementDashboardWebPartStrings;
  export = strings;
}
