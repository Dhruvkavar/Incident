import "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/fields";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import { getSP } from "./getSP";

export const spCall = (listName: string, select: string, expand: string, filter: string): any => {
    const _sp = getSP();
    return _sp.web.lists.getByTitle(listName).items.select(select).expand(expand).filter(filter).top(5000)();
    // return sp.web.lists.getByTitle(listName).items.select(select).expand(expand).filter(filter).orderBy("Modified",false).top(5000).get();
}

export const getListColumns = async (ListName:string): Promise<any[]> => {
    const _sp = getSP();
    try {
        const temp = _sp.web.lists.getByTitle(ListName);
        const tempList = await temp.fields.filter("").select("Title,InternalName,TypeAsString")();
        return tempList;
    } catch (error) {
        console.error('Error retrieving list columns:', error);
        return [];
    }
};

export const updateItem = (listName: string, itemId: number, obj: any): any => {
    const _sp = getSP();
    return _sp.web.lists.getByTitle(listName).items.getById(itemId).update(obj)
}

// export const deleteItem = (listName: string, itemId: number): any => {
//     const _sp = getSP();
//     return _sp.web.lists.getByTitle(listName).items.getById(itemId).recycle();
// };

export const deleteItem = async (listName: string, itemId: number): Promise<any> => {
    const _sp = getSP();
    try {
        const deletedItem = await _sp.web.lists.getByTitle(listName).items.getById(itemId).recycle();
        window.location.reload();
        return deletedItem;
    } catch (error) {
        // Handle errors here
        console.error("Error deleting item:", error);
        throw error; // Rethrow the error to propagate it up the call stack
    }
};

export const getAllListData = (listName: string, listcolumns: string,ExpandColumns:string, filterQuery:string):any => {
    let BoardApprovalRequestData: any[] = []
    return Promise.all([
        spCall(listName, listcolumns, ExpandColumns, filterQuery).then((items: any[]) => {
            BoardApprovalRequestData = items;
        }),
    ]).then(() => {
        const listObj = {
            BoardApprovalRequest: BoardApprovalRequestData,
        }
        return listObj;
    }).catch((error) => {
        return null;
    })
}