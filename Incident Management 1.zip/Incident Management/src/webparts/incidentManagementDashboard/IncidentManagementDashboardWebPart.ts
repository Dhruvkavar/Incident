import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'IncidentManagementDashboardWebPartStrings';
import IncidentManagementDashboard from './components/IncidentManagementDashboard';
import { IIncidentManagementDashboardProps } from './components/IIncidentManagementDashboardProps';
import { getSP } from './getSP';


export default class IncidentManagementDashboardWebPart extends BaseClientSideWebPart<IIncidentManagementDashboardProps> {


  public render(): void {
    const element: React.ReactElement<IIncidentManagementDashboardProps> = React.createElement(
      IncidentManagementDashboard,
      {
        ListName: this.properties.ListName,
        ListColumns: this.properties.ListColumns,
        context: this.context,
        viewEditURL: this.properties.viewEditURL,
        NewFormURL: this.properties.NewFormURL,
        PageTitle: this.properties.PageTitle
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    getSP(this.context);
    return super.onInit();
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: "Enter List Details"
          },
          groups: [
            {
              groupName: "",
              groupFields: [
                PropertyPaneTextField('ListName', {
                  label: strings.ListName
                }),
                PropertyPaneTextField('ListColumns', {
                  label: strings.ListColumns
                }),
                PropertyPaneTextField('viewEditURL', {
                  label: strings.viewEditURL
                }),
                PropertyPaneTextField('NewFormURL', {
                  label: "New Form URL"
                }),
                PropertyPaneTextField('PageTitle', {
                  label: "Page Title"
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
