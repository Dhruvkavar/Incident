import * as React from 'react';
import styles from '../components/IncidentManagementDashboard.module.scss';
import { Icon, Popup, PrimaryButton, Layer, FocusTrapZone, DefaultButton, Overlay, mergeStyleSets } from 'office-ui-fabric-react';
import '../assets/bootstrap.min.css';
import { deleteItem } from '../utils';
import * as moment from 'moment';
export interface IPropGrid {
    data: any;

}

const FGLogo = require('../assets/logo.png');

const ListName = 'Incident Management'
const DataTable: React.FunctionComponent<IPropGrid> = (props_cn: any) => {

    const popupStyles = mergeStyleSets({
        root: {
            background: 'rgba(0, 0, 0, 0.2)',
            bottom: '0',
            left: '0',
            position: 'fixed',
            right: '0',
            top: '0',
        },
        content: {
            background: 'white',
            left: '50%',
            maxWidth: '600px',
            padding: '10px 2em 2em',
            position: 'absolute',
            top: '50%',
            transform: 'translate(-50%, -50%)',
        },
    });
    const [isPopupVisible, setIsPopupVisible] = React.useState(false);
    const [selectedId, setSelectedId] = React.useState();
    // const url = props_cn.data.context?.pageContext?.web?.absoluteUrl;
    function getFieldValue(tableData: any, row: any): string {
        return tableData[row.InternalName] ? tableData[row.InternalName].toString() : "";
    }

    function DeleteListItemPopup(ID: any): any {
        deleteItem(ListName, ID);
    }

    // console.log(url

    function renderValueInHtml(value: string, item: any, element: any): any {
        if (value.length > 100) {
            value = value.substring(0, 100) + '...';
        }

        //value = value.replace(/(<([^>]+)>)/gi, "");

        if (item['odatatype'] === "SP.FieldDateTime") {
            const dateValue = new Date(element[item.InternalName]);

            return <div>{dateValue.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}</div>;
        }

        if (item.InternalName === "CreatedTime" || item.InternalName === "MIDeclaredTime" || item.InternalName === "ResolutionTime") {
            const dateValue = new Date(element[item.InternalName]);
            return <div>{moment(dateValue, "YYYY-MM-DDThh:mm:ss").format("YYYY/MM/DD hh:mm ")}</div>;
        }

        if (item['odatatype'] === "SP.FieldUrl") {
            return <div className={styles.DocLink} onClick={() => openLinkInNewTab(element[item.InternalName]?.Url)}>{element[item.InternalName]?.Url ? "Link" : ""}</div>
        }
        if (item['odatatype'] === "SP.FieldUser") {
            return <div className={styles.UserMail}><a href={"mailto:" + element[item.InternalName.replace("/Title", "")]?.EMail}>{element[item.InternalName.replace("/Title", "")]?.Title}</a></div>
        }

        if (item.InternalName === "ExistInModelToday") {
            return element[item.InternalName] ? "Yes" : "No"
        }
        if (item.InternalName === "field_12") {
            return <div>{element?.field_12?.replace(/<\/?[^>]+(>|$)/g, "")}</div>
        }
        if (item['odatatype'] === "CustomActionBtn") {
            // return <DefaultButton text='Edit' type='button' className={styles.EditBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=Edit")} />
            return <div className={styles.iconDiv}>
                <Icon iconName='Edit' className={styles.EditBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=Edit")} />
                <Icon iconName='View' className={styles.ViewBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=View")} />
                <Icon style={{ color: "red" }} className={styles.DeleteBtn} iconName='Delete' onClick={() => {
                    setIsPopupVisible(true);
                    setSelectedId(element.ID);
                    // window.location.reload();
                    // deleteItem(ListName, element.ID);
                }
                    //getAllListData(props_cn?.data?.listSPcall?.Listname, props_cn?.data?.listSPcall?.listcolumn, props_cn?.data?.listSPcall?.ExpandQuery, props_cn?.data?.listSPcall?.filterQuery)
                } /></div>
            // return <button type='button' className={styles.EditBtn} onClick={()=>openLinkInNewTab("https://torusitsolutions.sharepoint.com/sites/POC/ParkLand/SitePages/BoardApprovalRequest.aspx?itemID=" + element.ID+"&PageMode=Edit" )}>Edit </button>
        }
        // if (item['odatatype'] === "CustomEditBtn") {
        //     // return <DefaultButton text='Edit' type='button' className={styles.EditBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=Edit")} />
        //     return <Icon iconName='Edit' className={styles.EditBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=Edit")}/>
        //     // return <button type='button' className={styles.EditBtn} onClick={()=>openLinkInNewTab("https://torusitsolutions.sharepoint.com/sites/POC/ParkLand/SitePages/BoardApprovalRequest.aspx?itemID=" + element.ID+"&PageMode=Edit" )}>Edit </button>
        // }
        // if (item['odatatype'] === "CustomViewBtn") {
        //     // return <DefaultButton text='View' type='button' className={styles.ViewBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=View")} />
        //     return <Icon iconName='View' className={styles.ViewBtn} onClick={() => openLinkInNewTab(props_cn.data.viewEditURL + element.ID + "&PageMode=View")}/>
        //     // return <button type='button' className={styles.EditBtn} onClick={()=>openLinkInNewTab("https://torusitsolutions.sharepoint.com/sites/POC/ParkLand/SitePages/BoardApprovalRequest.aspx?itemID=" + element.ID+"&PageMode=Edit" )}>Edit </button>
        // }
        return <div>{value}</div>
    }
    function openLinkInNewTab(url: string): any {
        const newTab = window.open(url, '_self');
        newTab?.focus();
    }
    return (<>
        <div className={styles.gridStyles}>
            {/* <div className={styles.LogoAndTitle}> */}
            <div className='info'>
                {/* <div className={styles.Header}><img alt=" Logo" src={FGLogo} /><span className={styles.HeaderText}>Actuarial ALM Requirements</span><PrimaryButton style={{ background: "#7030a0", color: "#fff" }} text='New Request' onClick={() => window.open(props_cn.data.NewFormURL, '_self')} /></div> */}
                <div className={styles.Header}><img alt=" Logo" src={FGLogo} /><span className={styles.HeaderText}>{props_cn.data.PageTitle}</span><PrimaryButton className={styles.btnNewItem} text='New Request' onClick={() => window.open(props_cn.data.NewFormURL, '_self')} /></div>
                {/* <img src={FGLogo} className={styles.fgLogo}/>
                <h1 className={styles.DashboardHeader}>
                    Actuarial ALM Requirements Background
                </h1> */}
            </div>
            <div className={styles.tableDiv}>
                {
                    isPopupVisible
                    && (
                        <Layer>
                            <Popup
                                className={popupStyles.root}
                                role="dialog"
                                aria-modal="true"
                                onDismiss={() => setIsPopupVisible(false)}
                            >
                                <Overlay onClick={() => setIsPopupVisible(false)} />
                                <FocusTrapZone>
                                    <div role="document" className={popupStyles.content}>
                                        <p className={styles.PopupText}>
                                            Are you sure you want to delete this item?
                                        </p>
                                        <div className={styles.PopUpBtns}>
                                            <PrimaryButton onClick={() => { DeleteListItemPopup(selectedId); setIsPopupVisible(false) }} className={styles.Yesbtn}>Yes</PrimaryButton>
                                            <DefaultButton onClick={() => { setIsPopupVisible(false) }}>No</DefaultButton>
                                        </div>
                                    </div>
                                </FocusTrapZone>
                            </Popup>
                        </Layer>
                    )}
                <table className='table table-hover table-bordered'>
                    <thead>
                        <tr>
                            {props_cn.data.SelectedListColumns?.map((element: any, i: number) => {
                                return (
                                    <th key={"td_" + i} style={{
                                        maxWidth: element.width ? element.width : "300px",
                                        minWidth: element.width ? element.width : "auto",
                                        borderRight: "1px solid white", background: "#7030a0", color: "#fff"
                                    }}>
                                        {element.DisplayName}
                                    </th>
                                )
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {
                            props_cn.data.BoardApprovalRequestData
                                ?.sort((a: any, b: any) => b.Id - a.Id)
                                .map((element: any) => {
                                    return (
                                        <tr key={element.id}>
                                            {
                                                props_cn.data?.SelectedListColumns.map((item: any) => {
                                                    return (
                                                        <td key={item} style={{ minWidth: item.width ? item.width : "auto" }}>
                                                            <div>
                                                                {renderValueInHtml(getFieldValue(element, item), item, element)}
                                                            </div>
                                                        </td>
                                                    )
                                                })}
                                        </tr>
                                    )
                                })
                        }
                    </tbody>
                </table>
            </div>
        </div>
    </>
    )
}
export default DataTable;