import * as React from 'react';
import styles from './IncidentManagementDashboard.module.scss';
import { IIncidentManagementDashboardProps } from './IIncidentManagementDashboardProps';
import { escape } from '@microsoft/sp-lodash-subset';
import DataTable from '../ChildComponent/DataTable';
import { getAllListData, getListColumns } from '../utils';

const IncidentManagementDashboard: React.FunctionComponent<IIncidentManagementDashboardProps> = (props: IIncidentManagementDashboardProps) => {
  const [data, setAllData] = React.useState({
    BoardApprovalRequestData: [],
    SelectedListColumns: [] as any,
    context: {},
    viewEditURL: "",
    NewFormURL: "",
    PageTitle: ""
  });
  React.useEffect(() => {
    LoadListData();
  }, [props])

  //const checkFullControlPermission = (): boolean => {
  //  let permission = new SPPermission(props.context.pageContext.web.permissions.value);
  //  const isFullControl = permission.hasPermission(SPPermission.manageWeb);
  // return isFullControl;
  //}


  const LoadListData = async (): Promise<any> => {
    const ListColumnValues: any = await getListColumns(props?.ListName);
    const SelectQueryArr: any[] = [];
    const ExpandQueryArr: any[] = [];
    const tempColumnArr: any[] = [];
    JSON.parse(props?.ListColumns).forEach((x: any) => {
      const temp = ListColumnValues.filter((m: any) => m?.InternalName === x.InternalName)[0]

      if (temp?.['odata.type'] === "SP.FieldLookup") {
        SelectQueryArr.push({ InternalName: (temp?.InternalName + "/Title"), odatatype: temp?.['odata.type'] })
        tempColumnArr.push({ ...x, InternalName: (temp?.InternalName + "/Title"), odatatype: temp?.['odata.type'] })
        ExpandQueryArr.push(temp?.InternalName)
      } else if (temp?.['odata.type'] === "SP.FieldUser") {
        SelectQueryArr.push({ InternalName: (temp?.InternalName + "/Title"), odatatype: temp?.['odata.type'] })
        tempColumnArr.push({ ...x, InternalName: (temp?.InternalName + "/Title"), odatatype: temp?.['odata.type'], })
        SelectQueryArr.push({ InternalName: (temp?.InternalName + "/EMail"), odatatype: temp?.['odata.type'] })
        ExpandQueryArr.push(temp?.InternalName)
      }
      else {
        SelectQueryArr.push({ InternalName: (temp?.InternalName), odatatype: temp?.['odata.type'] })
        tempColumnArr.push({ ...x, InternalName: (temp?.InternalName), odatatype: temp?.['odata.type'] })
      }
    })

    let SelectQuery = SelectQueryArr.length > 0 ? SelectQueryArr.map(obj => obj.InternalName).join(',') : ""
    const ExpandQuery = ExpandQueryArr.length > 0 ? ExpandQueryArr.join(',') : ""

    //const listcolumn = JSON.parse(props?.ListColumns).map((a: any) => a.InternalName).join(",")

    //Added filter query to get only my items if i don't have full control permission on site
    let filterQuery = "";//checkFullControlPermission() ? "" : "Author/EMail eq'" + props.context.pageContext._user.email + "'"

    const response: any = await getAllListData(props?.ListName, "ID," + SelectQuery, ExpandQuery, filterQuery);

    const updatedBoardApprovalRequest = response?.BoardApprovalRequest.map((item: any) => {
      return {
        ...item,
        EditBtn: 'true',
      };
    });

    if (response !== null) {
      tempColumnArr.push({ InternalName: 'ActionBtn', odatatype: 'CustomActionBtn', DisplayName: "Action", width: "90px" })
      // tempColumnArr.push({ InternalName: 'EditBtn', odatatype: 'CustomEditBtn' })
      // tempColumnArr.push({ InternalName: 'ViewBtn', odatatype: 'CustomViewBtn' })
      setAllData({
        BoardApprovalRequestData: updatedBoardApprovalRequest,
        SelectedListColumns: tempColumnArr,
        context: props.context,
        viewEditURL: props.viewEditURL,
        NewFormURL: props.NewFormURL,
        PageTitle: props.PageTitle
      });
    }
  }


  return (
    <>
      <div>
        {
          <div className={`row`}>
            <div className='col-sm-12'>
              <DataTable data={data} />
            </div>
          </div>
        }
      </div>
    </>
  )
}
export default IncidentManagementDashboard
