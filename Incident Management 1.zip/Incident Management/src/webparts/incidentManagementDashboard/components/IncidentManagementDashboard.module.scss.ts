/* tslint:disable */
require("./IncidentManagementDashboard.module.css");
const styles = {
  overlay: 'overlay_8cc35be1',
  overlay__inner: 'overlay__inner_8cc35be1',
  overlay__content: 'overlay__content_8cc35be1',
  spinner: 'spinner_8cc35be1',
  spin: 'spin_8cc35be1',
  headerWrapper: 'headerWrapper_8cc35be1',
  headerName: 'headerName_8cc35be1',
  inputFormWrapper: 'inputFormWrapper_8cc35be1',
  'col-sm-12': 'col-sm-12_8cc35be1',
  DocLink: 'DocLink_8cc35be1',
  UserMail: 'UserMail_8cc35be1',
  gridStyles: 'gridStyles_8cc35be1',
  tableDiv: 'tableDiv_8cc35be1',
  iconDiv: 'iconDiv_8cc35be1',
  EditBtn: 'EditBtn_8cc35be1',
  ViewBtn: 'ViewBtn_8cc35be1',
  DeleteBtn: 'DeleteBtn_8cc35be1',
  btnNewItem: 'btnNewItem_8cc35be1',
  fgLogo: 'fgLogo_8cc35be1',
  DashboardHeader: 'DashboardHeader_8cc35be1',
  LogoAndTitle: 'LogoAndTitle_8cc35be1',
  Header: 'Header_8cc35be1',
  HeaderText: 'HeaderText_8cc35be1',
  PopUpBtns: 'PopUpBtns_8cc35be1',
  Yesbtn: 'Yesbtn_8cc35be1',
  PopupText: 'PopupText_8cc35be1'
};

export default styles;
/* tslint:enable */