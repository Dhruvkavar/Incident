export interface IIncidentManagementDashboardProps {
  ListName: string;
  ListColumns: string;
  viewEditURL: string;
  context: any;
  NewFormURL: string;
  PageTitle:string;
}
